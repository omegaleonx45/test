require "./ListaRuby"

@name
@lastName
@typeDocument
@document
@documentMod

def agregarPersona
  p "nombre"
  @name = gets.chomp
  p "apellido"
  @lastName = gets.chomp
  p "tipo de documento"
  @typeDocument = gets.chomp
  p "Numero del documento"
  @document = gets.chomp
end

lista = Lista.new
loop do
    p "Por favor ingrese No. de la actividad a realizar"
    p "1 Nueva Persona"
    p "2 Modificar"
    p "3 Eliminar"
    p "4 Buscar por No. documento"
    p "5 Imprimir"
    p "6 salirse del programa"
    menu = gets.to_i
    case menu
        when 1
          agregarPersona
          lista.agregarNodo(@name,@lastname,@typeDocument,@document)
        when 2
            p " "
            p "Numero del documento a modificar"
            @documentMod = gets.chomp
            agregarPersona
            lista.modificarNodo(@documentMod,@name,@lastname,@typeDocument,@document)
        when 3
            p "Eliminar"
            agregarPersona
            lista.eliminarNodo(@name,@lastname,@typeDocument,@document)
        when 4
            p "Busqueda"
            p "Numero del documento a buscar"
            @documentMod = gets.chomp
            lista.buscarPersona(@documentMod,"","","","")
        when 5
            p "Impresion"
          if !lista
            menu = 1
            p "error por favor ingrese alguna persona"
          else
            lista.imprimirLista
          end
        when 6
          p "Ha salido del programa"
        else
        p "error"
    end
    p " "
  break if menu > 5
end
p "Si desea ingresar nuevamente, ejecute el aplicativo de nuevo"
